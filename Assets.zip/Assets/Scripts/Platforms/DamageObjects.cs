using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DamageObjects : MonoBehaviour
{
    private void OnTriggerEnter2D(CapsuleCollider2D collision)
    {
        if(collision.transform.CompareTag("Player")){
            Debug.Log("Player Died");
            collision.transform.GetComponent<PlayerRespawn>().PlayerDied();
        }
    }

    public void PlatformSpikes(){
        
    }
}